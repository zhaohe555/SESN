# coding=gbk
from numpy import *
import numpy as np
from scipy.stats import pearsonr
import random
import readfile_fruitfly
import time
def readgo(gofilename, vertax):
    pro_go = {}
    for eachpro in vertax:
        pro_go.update({eachpro: []})
    file_go = open(gofilename)
    for eachline in file_go:
        (a, b) = eachline.split()
        if a in vertax:
            pro_go[a].append(b)
    return pro_go
def goScore(e,pro_go,pro1):
    e_go = {}  # {[pro1,pro2]:goscore,...}
    for eachedge in e:
        go_score = 0
        pro1_go = pro_go[pro1[eachedge[0]]]
        pro2_go = pro_go[pro1[eachedge[1]]]
        pro1_pro2_and = list(set(pro1_go) & set(pro2_go))  # intersection
        if (len(pro1_go)*len(pro2_go)) != 0:
            go_score = (len(pro1_pro2_and) ** 2) / (len(pro1_go)*len(pro2_go))
        e_go.update({tuple(eachedge): go_score})
    return e_go
def go_score_subnet(e_sub,e_go,pro_readfile,pro1_subnet):
    e_go_subnet = {}
    for each in e_sub:
        a_sub= each[0]
        b_sub = each[1]
        a = pro_readfile[pro1_subnet[a_sub]]
        b = pro_readfile[pro1_subnet[b_sub]]
        e_go_subnet.update({tuple(each):e_go[(a,b)]})
    return e_go_subnet

def subcellerScore(subcellerfilename, vertax, subceller_11, pro, subceller_11_protein):
    subceller_remove_file = open(subcellerfilename)
    subceller_remove = []
    for eachline in subceller_remove_file:
        a = eachline.replace('\n', '')
        (b, c,d) = a.split('\t')
        subceller_remove.append([b, d])
    # select subcellular localization
    somedatabase_protein_subceller = []
    for each in subceller_remove:
        if each[0] in vertax:
            somedatabase_protein_subceller.append(each)
    # number of protein in subcellular localization��
    subceller_11_proteinscore = {}
    for each in subceller_11.keys():
        subceller_11_proteinscore.update({each: 0})
    maxscore = 0 #max��protein number of all subcellular localization��
    for i in subceller_11_proteinscore.keys():
        eachprotein = []
        for each in somedatabase_protein_subceller:
            if i == each[1]:
                if each[0] not in eachprotein:
                    subceller_11_proteinscore[i] = subceller_11_proteinscore[i] + 1
                    eachprotein.append(each[0])
        subceller_11_protein[i] = eachprotein
        if subceller_11_proteinscore[i] > maxscore:
            maxscore = subceller_11_proteinscore[i]
    # score of subcellular localization��protein number/max
    for each in subceller_11.keys():
        if maxscore != 0:
            subceller_11[each] = subceller_11_proteinscore[each]/maxscore
    # score of protein based on subcellular localization
    pro_subceller_11 = {}
    for each in range(len(vertax)):
        pro_subceller_11.setdefault(each, [])
    for each in somedatabase_protein_subceller:
        if each[1] in subceller_11.keys():
            pro_subceller_11[pro[each[0]]].append(each[1])
    # score of protein based on subcellular localization
    score_subceller = {}
    for each in vertax:
        score_eachvertax = 0
        for eachsubceller in pro_subceller_11[pro[each]]:
            score_eachvertax = score_eachvertax + subceller_11[eachsubceller]
        score_subceller[each] = score_eachvertax
    maxvalue = max(score_subceller.values())
    for each in vertax:
        score = (score_subceller[each]) / (maxvalue)
        score_subceller[each] = score
    return score_subceller

def gene_expressionScore(geneexpression_filename, vertax, e, pro1):
    gene_expression = open(geneexpression_filename)
    gene_expression_haveprotein = []
    gene_expression_haveprotein_onecycle = []  # (protein+34 sample points)
    gene_ex_allpro_inppi = []  #  protein <-> gene expression
    protein_dynamic_score = {}
    for each in gene_expression:
        eachline = each.split()
        if (eachline[0] in vertax) & (eachline[0] not in gene_ex_allpro_inppi):
            gene_expression_haveprotein.append(eachline)
            gene_ex_allpro_inppi.append(eachline[0])
    for each in gene_expression_haveprotein:
        each_gene_expression_data = each[1:]
        gene_expression_onecycle = []
        gene_expression_onecycle.append(each[0])
        i = 0
        while i != 136:
            mean_gene_expression_data = (float(each_gene_expression_data[i]) +
                                         float(each_gene_expression_data[i + 1]) +
                                         float(each_gene_expression_data[i + 2]) +
                                         float(each_gene_expression_data[i + 3])) / 4
            i = i + 4
            gene_expression_onecycle.append(mean_gene_expression_data)
        gene_expression_haveprotein_onecycle.append(gene_expression_onecycle)
    for eachedge in e:
        protein1 = pro1[eachedge[0]]  # id_name
        protein2 = pro1[eachedge[1]]
        if (protein1 in gene_ex_allpro_inppi) and (protein2 in gene_ex_allpro_inppi):
            x = []
            y = []
            for each in gene_expression_haveprotein_onecycle:
                if each[0] == protein1:
                    x = each[1:]
                if each[0] == protein2:
                    y = each[1:]
            score = pearsonr(x, y)[0]  #Pearson correlation coefficient
            score = (score + 1) / 2
            protein_dynamic_score.update({tuple(eachedge): score})
        else:
            protein_dynamic_score.update({tuple(eachedge): 0})
    return protein_dynamic_score

def score_initial(alpha1, alpha2, alpha3, alpha4, e_go, proteincomplex_filename, geneexpr_score, score_subceller, vertax,e,pro1,pro,Neighbor):
    file_proteincomplex = open(proteincomplex_filename)
    proteincomplex = []
    for eachline in file_proteincomplex:
        eachproteincomplex = eachline.split()
        proteincomplex.append(eachproteincomplex)
    protein_frequencycomplex = {}
    for each in vertax:
        protein_frequencycomplex.setdefault(each, 0)
    for eachcomplex in proteincomplex:
        for eachprotein in eachcomplex:
            if eachprotein in vertax:
                protein_frequencycomplex[eachprotein] = protein_frequencycomplex[eachprotein]+1
    maxvalue = max(protein_frequencycomplex.values())
    procomplex_geneexpr_score = {}
    WAdjacent = [[0] * len(vertax) for i in range(0, len(vertax))]
    for eache in e:
        i = eache[0]
        j = eache[1]
        WAdjacent[i][j] = e_go[tuple(eache)]**alpha1\
                          *geneexpr_score[tuple(eache)]**alpha2\
                          *(protein_frequencycomplex[pro1[i]]\
                          *protein_frequencycomplex[pro1[j]]/(maxvalue**2))**alpha3
        WAdjacent[j][i] = WAdjacent[i][j]
    for each in vertax:
        i = pro[each]
        score = 0
        for eachnei in Neighbor[pro[each]]:
            j = eachnei
            score = score + WAdjacent[i][j]
        procomplex_geneexpr_score[each] = score*(score_subceller[each]**alpha4)
    return procomplex_geneexpr_score

# Construct PPI sub-networks by gene expression data
def dynamicPPI(geneexpression_filename, vertax, protein_dynamic_score, gene_ex_allpro_inppi):
    gene_expression = open(geneexpression_filename)
    gene_expression_haveprotein = []
    for each in gene_expression:
        eachline = each.split()
        if (eachline[0] in vertax) & (eachline[0] not in gene_ex_allpro_inppi):
            gene_expression_haveprotein.append(eachline)
            gene_ex_allpro_inppi.append(eachline[0])
    for each in gene_expression_haveprotein:
        each_gene_expression_data = each[1:]
        gene_expression_onecycle = []
        i = 0
        while i != 136:
            mean_gene_expression_data = (float(each_gene_expression_data[i]) +
                                         float(each_gene_expression_data[i + 1]) +
                                         float(each_gene_expression_data[i + 2]) +
                                         float(each_gene_expression_data[i + 3])) / 4
            i = i + 4
            gene_expression_onecycle.append(mean_gene_expression_data)
        mean = np.mean(gene_expression_onecycle)
        std = np.std(gene_expression_onecycle)
        f = 1 / (1 + std ** 2)
        active_th_3 = mean + 3 * std * (1 - f)
        active_th_2 = mean + 2 * std * (1 - f)
        active_th_1 = mean + std * (1 - f)
        for i in range(34):
            if gene_expression_onecycle[i] >= active_th_3:
                protein_dynamic_score[each[0]].append(0.99)
            elif gene_expression_onecycle[i] >= active_th_2:
                protein_dynamic_score[each[0]].append(0.95)
            elif gene_expression_onecycle[i] >= active_th_1:
                protein_dynamic_score[each[0]].append(0.68)
            else:
                protein_dynamic_score[each[0]].append(0)

def wmatrix(beta1, beta2, beta3, beta4, geneexpr_score,proteincomplex_filename,vertax, e, e_go, score_subceller,pro1,pro_readfile):
    file_proteincomplex = open(proteincomplex_filename)
    proteincomplex = []
    for eachline in file_proteincomplex:
        eachproteincomplex = eachline.split()
        proteincomplex.append(eachproteincomplex)
    protein_frequencycomplex = {}
    for each in vertax:
        protein_frequencycomplex.setdefault(each, 0)
    for eachcomplex in proteincomplex:
        for eachprotein in eachcomplex:
            if eachprotein in vertax:
                protein_frequencycomplex[eachprotein] = protein_frequencycomplex[eachprotein] + 1
    maxvalue = max(protein_frequencycomplex.values())
    Wmatrix = [[0] * len(vertax) for i in range(0, len(vertax))]
    for eachedge in e:
        Wmatrix[eachedge[0]][eachedge[1]] = geneexpr_score[tuple(eachedge)]**beta1\
                                            *e_go[tuple(eachedge)]**beta2\
                                            *(score_subceller[pro1[eachedge[0]]]*score_subceller[pro1[eachedge[1]]])**beta3\
                                            *(protein_frequencycomplex[pro1[eachedge[0]]]*protein_frequencycomplex[pro1[eachedge[1]]]/(maxvalue**2))**beta4
        Wmatrix[eachedge[1]][eachedge[0]] = Wmatrix[eachedge[0]][eachedge[1]]
    return Wmatrix

def allneibor(K,Ki, Nei):
    allNei = set()
    for eachessenpro in Ki:
        nei = Nei[eachessenpro]
        allNei = allNei|set(nei)
    allNei = allNei-set(K)
    return list(allNei)

def accresult(essentialprotein, K, vertax):
    TP = 0
    for i in K:
        if i in essentialprotein:
            TP = TP + 1
    FP = len(K) - TP
    FN = 0
    for i in list(set(vertax)-set(K)):
        if i in essentialprotein:
            FN = FN+1
    TN = len(vertax)- len(K) -FN
    SN = TP / (TP + FN)
    SP = TN / (TN + FP)
    PPV = TP / (TP + FP)
    NPV = TN / (TN + FN)
    Fmeasure = 2 * SN * PPV / (SN + PPV)
    ACC = (TP + TN) / (TP + TN + FP + FN)
    print('SN:', SN, ' ', 'SP:', SP, ' ', 'PPV:', PPV)
    print('NPV:', NPV, ' ', 'Fmeasure:', Fmeasure, ' ', 'ACC:', ACC, '\n')
    return ACC

def resultfile(filename, kscore, k, vertax):
    len1 = len(k)
    score = len1
    for each in k:
        kscore[each] = score / len1
        score = score - 1
    for eachv in vertax:
        if eachv not in k:
            kscore[eachv] = 0
    file = open(filename, 'w')
    for each in kscore:
        file.write(str(each) + '\t' + str(kscore[each]) + '\n')
    file.close()

starttime = time.time()
gofilename = 'go_fruitfly.txt'
pro_go = readgo(gofilename, readfile_fruitfly.vertax)
e_go = goScore(readfile_fruitfly.e, pro_go, readfile_fruitfly.pro1)
proteincomplex_filename  = 'complex_fruitfly.txt'
geneexpression_filename = 'geneexpression_fruitfly.txt'
geneexpr_score = gene_expressionScore(geneexpression_filename, readfile_fruitfly.vertax, readfile_fruitfly.e, readfile_fruitfly.pro1)
subcellerfilename = 'subceller_fruitfly.txt'
subceller_11 = {'Nucleus': 0, 'Cytosol': 0, 'Cytoskeleton': 0,
                'Endoplasmic reticulum': 0, 'Golgi apparatus': 0}
subceller_11_protein = {}
for each in subceller_11.keys():
    subceller_11_protein.setdefault(each, [])
score_subceller = subcellerScore(subcellerfilename, readfile_fruitfly.vertax, subceller_11, readfile_fruitfly.pro, subceller_11_protein)

acc_max = 0
parameter_max = ()
K_max = []
parameters = []
parameters.append([1, 1, 1, 1, 1, 1, 1, 1])
for i in range(8):
    gg = [1, 1, 1, 1, 1, 1, 1, 1]
    gg[i] = 0
    item = gg
    parameters.append(item)

for (alpha1, alpha2, alpha3, alpha4, beta1, beta2, beta3, beta4) in parameters:
    try:
        # Initialization of the whole PPI network and PPI sub-networks
        procomplex_geneexpr_score =score_initial(alpha1, alpha2, alpha3, alpha4, e_go,proteincomplex_filename, geneexpr_score, score_subceller, readfile_fruitfly.vertax,readfile_fruitfly.e,readfile_fruitfly.pro1,readfile_fruitfly.pro,readfile_fruitfly.Neighbor)
        protein_dynamic_score = {}
        for each in readfile_fruitfly.vertax:
            protein_dynamic_score.setdefault(each, [])  # {protein1 ��[score1,...,score34],....}
        gene_ex_allpro_inppi = []
        dynamicPPI(geneexpression_filename, readfile_fruitfly.vertax, protein_dynamic_score, gene_ex_allpro_inppi)
        variable = locals()
        for j in range(34):
            variable['edgescore' + str(j)] = {}
            variable['escore' + str(j)] = {}
            variable['edge' + str(j)] = []
            variable['vertax' + str(j)] = []
            variable['e' + str(j)] = []
            variable['pro' + str(j)] = {}
            variable['pro1' + str(j)] = {}
            variable['K' + str(j)] = []
            variable['Neighbor'+str(j)] = {} #id_num
            variable['Nei'+str(j)] = {} #id_name
        for each in readfile_fruitfly.edge:
            protein1 = each[0]
            protein2 = each[1]
            if (protein1 in gene_ex_allpro_inppi) & (protein2 in gene_ex_allpro_inppi):
                for i in range(34):
                    a = protein_dynamic_score[protein1]
                    b = protein_dynamic_score[protein2]
                    if a[i] * b[i] > 0:
                        score = a[i] * b[i]
                        variable['edge' + str(i)].append(each)
                        variable['edgescore' + str(i)][tuple(each)] = score
        for j in range(34):
            for each in variable['edge' + str(j)]:
                protein1 = each[0]
                protein2 = each[1]
                if protein1 not in variable['vertax'+str(j)]:
                    variable['vertax'+str(j)].append(protein1)
                if protein2 not in variable['vertax'+str(j)]:
                    variable['vertax'+str(j)].append(protein2)
            readfile_fruitfly.protein_to_number(variable['vertax'+str(j)], variable['pro' + str(j)], variable['pro1' + str(j)]
                                       , variable['edge' + str(j)], variable['e' + str(j)])
            readfile_fruitfly.proteinNeighber(variable['vertax'+str(j)],variable['pro1' + str(j)], variable['Nei'+str(j)],
                                     variable['Neighbor'+str(j)],variable['e' + str(j)])
            for each in variable['edge' + str(j)]:
                edge = each
                a = edge[0]
                b = edge[1]
                e = (variable['pro' + str(j)][a],variable['pro' + str(j)][b])
                variable['escore' + str(j)][e] = variable['edgescore' + str(j)][tuple(each)]
            variable['e_go' + str(j)] = go_score_subnet(variable['e' + str(j)], e_go, readfile_fruitfly.pro, variable['pro1' + str(j)])
            variable['Wmatrix_ts' + str(j)] = wmatrix(beta1, beta2, beta3, beta4, variable['escore' + str(j)], proteincomplex_filename, variable['vertax' + str(j)], variable['e' + str(j)],variable['e_go' + str(j)], score_subceller,variable['pro1' + str(j)],readfile_fruitfly.pro)
        # Initialize the state of all proteins in PPI: not removed
        removefalg = {}
        for each in readfile_fruitfly.vertax:
            removefalg[each] = 0
        # Initialization of K, Ki, Length of K
        variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)] = []
        for j in range(34): #number of Ki=34
            k = random.choice(variable['vertax' + str(j)])
            while k in variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)]:
                k = random.choice(variable['vertax' + str(j)])
            variable['K' + str(j)].append(k)
            variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)].append(k)
        N = int(len(readfile_fruitfly.vertax)*0.1)
        # Seed expand process
        while len(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)])<N:
            Wmatirx_maxscore = 0
            procomplex_gene_max = 0
            procomplex_gene_min = float('inf')
            procomplex_gene_min_pro = ''
            procomplex_gene_maxpro = ''
            Wmatirx_maxpro = ''
            for each in variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)]:
                if procomplex_geneexpr_score[each] < procomplex_gene_min and removefalg[each] == 0:
                    procomplex_gene_min = procomplex_geneexpr_score[each]
                    procomplex_gene_min_pro = each
            allNei_K = allneibor(variable['K' + str(alpha1) + str(alpha2) + str(alpha3) + str(alpha4) + str(beta1) + str(
                beta2) + str(beta3) + str(beta4)],
                                 variable['K' + str(alpha1) + str(alpha2) + str(alpha3) + str(alpha4) + str(beta1) + str(
                                     beta2) + str(beta3) + str(beta4)],
                                 readfile_fruitfly.Nei)
            for each in allNei_K:
                if procomplex_geneexpr_score[each] > procomplex_gene_max:
                    procomplex_gene_max = procomplex_geneexpr_score[each]
                    procomplex_gene_maxpro = each

            for j in range(34):
                allNei_ts = allneibor(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)],variable['K' + str(j)], variable['Nei'+str(j)])
                submaxscore_Wmatr = 0
                maxpro_Wmatr =''
                for each in allNei_ts:
                    usenei = set(variable['Nei'+str(j)][each]) & (set(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)]))
                    score_Wmatr = 0
                    for eachone in usenei:
                        score_Wmatr = score_Wmatr + variable['Wmatrix_ts' + str(j)][variable['pro' + str(j)][each]][variable['pro' + str(j)][eachone]]
                    if score_Wmatr >= submaxscore_Wmatr:
                        submaxscore_Wmatr = score_Wmatr
                        maxpro_Wmatr = each
                if submaxscore_Wmatr>Wmatirx_maxscore:
                    Wmatirx_maxscore = submaxscore_Wmatr
                    Wmatirx_maxpro = maxpro_Wmatr
            # Seed expand
            if Wmatirx_maxpro not in variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)]:
                variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)].append(Wmatirx_maxpro)
                # Update Ki
                for i in range(34):
                    if variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)][-1] in variable['vertax' + str(i)]:
                        variable['K' + str(i)].append(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)][-1])
            else:
                print('eccerro')
            # Erro correction
            if procomplex_gene_max > procomplex_gene_min:
                if procomplex_gene_maxpro not in variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)]:
                    variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)].append(procomplex_gene_maxpro)
                    # Update Ki
                    for i in range(34):
                        if variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)][-1] in variable['vertax' + str(i)]:
                            variable['K' + str(i)].append(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)][-1])
                    if removefalg[procomplex_gene_min_pro] == 0:
                        variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)].remove(procomplex_gene_min_pro)
                        #Update Ki and the state of the removed node
                        removefalg[procomplex_gene_min_pro] = 1
                        for i in range(34):
                            if procomplex_gene_min_pro in variable['K' + str(i)]:
                                variable['K' + str(i)].remove(procomplex_gene_min_pro)
        print('parameters:', (alpha1, alpha2, alpha3, alpha4, beta1, beta2, beta3, beta4))
        ACC = accresult(readfile_fruitfly.essentialprotein, variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)], readfile_fruitfly.vertax)
        if ACC > acc_max:
            acc_max = ACC
            parameter_max = (alpha1, alpha2, alpha3, alpha4, beta1, beta2, beta3, beta4)
            K_max = []
            for ccc in range(len(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)])):
                K_max .append(variable['K'+str(alpha1)+str(alpha2)+str(alpha3)+str(alpha4)+str(beta1)+str(beta2)+str(beta3)+str(beta4)][ccc])
    except Exception as e:
        print('erro��������������������������������', e)
        print('\n','\n','\n')
        pass
    continue
filename = 'result_SESN_fruitfly.txt'
K_score = {}
resultfile(filename, K_score, K_max, readfile_fruitfly.vertax)
print('Maximum acc', acc_max)
print('parameters of Maximum', parameter_max)
endtime = time.time()
runtime = endtime - starttime
print('runtime ', runtime)


