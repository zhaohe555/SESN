# coding=gbk
import time
from numpy import *
import numpy as np
# coding=gbk
import time
import numpy as np

def readPPIdata (ppifilename, edge, vertax):
    file_ppi = open(ppifilename)
    protein = []
    for eachline in file_ppi:
        (a, b) = eachline.split()
        if (a != b) and ([a, b] not in edge):
            edge.append([a, b])
            protein.append(a)
            protein.append(b)
    for each in protein:
        if each not in vertax:
            vertax.append(each)

def protein_to_number(vertax, pro, pro1, edge, e):
    i = 0
    for eachprotein in vertax:
        pro.update({eachprotein: i})
        pro1.update({i: eachprotein})
        i = i + 1

    for eachedge in edge:
        eachedge_new = []
        for eachpro in eachedge:
            eachpro_new = pro[eachpro]
            eachedge_new.append(eachpro_new)
        e.append(eachedge_new)
    #print('The protein number of this dataset:', len(vertax))

def readEssentialProtein(essentialproteinfilename, vertax, essentialprotein,essentialprotein_in_database):
    essentialprotein_file = open(essentialproteinfilename)

    for eachline in essentialprotein_file:
        a = eachline.replace('\n', '')
        essentialprotein.append(a)
    essentialprotein_file.close()
    for each in vertax:
        if each in essentialprotein:
            essentialprotein_in_database.append(each)
    #print('The essential protein number of this dataset', len(essentialprotein_in_database))

def adjacentMatrix(e, vertax):
    Adjacent = [[0] * len(vertax) for i in range(0, len(vertax))]
    for eachedge in e:
        Adjacent[eachedge[0]][eachedge[1]] = 1.0
        Adjacent[eachedge[1]][eachedge[0]] = 1.0
    return Adjacent

def proteinNeighber(vertax,pro1, Nei, Neighbor,e):
    for i in range(len(vertax)):
        Neighbor[i] = []#id_number
        Nei[pro1[i]] = []#id_name
    for eache in e:
        i= eache[0]
        j= eache[1]
        Neighbor[i].append(j)
        Nei[pro1[i]].append(pro1[j])
        Neighbor[j].append(i)
        Nei[pro1[j]].append(pro1[i])
def main1():
    global pro
    pro = {}  # id_number
    global pro1
    pro1 = {}  # number:name
    global edge
    edge = []
    global e
    e = []  # (number,number)
    global vertax
    vertax = []
    global essentialprotein
    essentialprotein = []
    global essentialprotein_in_database
    essentialprotein_in_database = []
    global Neighbor #id_number
    Neighbor = {}
    global Nei #id_name
    Nei = {}
    global Adjacent
    essentialproteinfilename = 'essentialprotein.txt'
    ppifilename =   'dip.txt'
    readPPIdata(ppifilename, edge, vertax)
    protein_to_number(vertax, pro, pro1, edge, e)
    readEssentialProtein(essentialproteinfilename, vertax, essentialprotein, essentialprotein_in_database)
    proteinNeighber(vertax, pro1, Nei, Neighbor,e)


main1()