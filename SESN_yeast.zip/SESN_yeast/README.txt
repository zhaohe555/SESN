1.Software version:

The Python code is written for Python 3.8.

2.The information of files:

PPI data: DIP.txt; biogrid.txt

Essential protein: essentialprotein.txt

Biological data: go_slim.txt; gene_expression.txt; protein_complex.txt; subceller_remove.txt

3.Usage

If you want to change PPI data, please change PPI networks(ppifilename) in the file "readfile.py".

4.Result analysis

(1) Output the experimental results of nine groups parameters, respectively.
(2) The best results of SESN are written in 'result_SESN.txt'.