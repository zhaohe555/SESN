1.Software version:

The Python code is written for Python 3.8.

2.The information of files:

PPI data: ppi_fruitfly.txt

Essential protein: essentialprotein_fruitfly.txt

Biological data: go_fruitfly.txt; geneexpression_fruitfly.txt; complex_fruitfly.txt; subceller_fruitfly.txt


3.Result analysis

(1) Output the experimental results of nine groups parameters, respectively.
(2) The best results of SESN_fruitfly are written in 'result_SESN_fruitfly.txt'.